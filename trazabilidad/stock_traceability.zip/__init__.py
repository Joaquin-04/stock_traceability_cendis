# stock_traceability/__init__.py
from . import models

