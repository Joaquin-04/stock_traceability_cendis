# stock_traceability/models/__init__.py
from . import stock_traceability
